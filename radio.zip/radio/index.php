<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title></title>
    </head>
    <style>
        @font-face {
		font-family: "Testando";
		src: url("fonts/coco.ttf"); /* para IE */
		
	}
	#texto{ 
		font-family: "Testando"; 
	}
	@font-face {
		font-family: "numero";
		src: url("fonts/nexa.otf"); /* para IE */
		
	}
	#teste{ 
		font-family: "numero"; 
	}
        #radios img{
            width: 70px;
            height: 70px;
        }
        body{
            background-image: url("imagens/BG.jpg"); 
            color: #f0fd5f;
            font-size: 15px;
        }
    </style>
    <body >
        <div id="container" >
            <div id="logo" >
                <center><img src="imagens/logo.png"></center>
            </div>
            <div id="radios" style="width: 100%;">
                <div id="es" style="float: left; width: 40%;">
                    <center>
                        <br><div>
                            <label id="texto">Rede</label>
                            
                        </div><br> 
                        <audio id="audio"  preload="auto" type="audio/mp3">
                            <source src="http://198.24.156.115:9300/;" type="audio/ogg">
                        </audio>
                        <div>
                            <a href="#" onclick="play()"  id="play"><img src="imagens/play.png"></a>
                            <a href="#" onclick="pause()" style="display:none;" id="pause"><img src="imagens/pause.png"></a>     
                        </div></center>
                </div>
                <div id="di" style="float: right; width: 40%;">
                    <center>
                        <br><div>
                            <label id="texto">Paraipaba - </label>
                            <label id="teste">88.7</label>
                        </div><br> 
                        <audio id="audio2" preload="auto">
                            <source src="http://198.24.156.115:9302/;" type="audio/ogg">
                        </audio>
                        <div>
                            <a href="#" onclick="play2()" id="play2"><img src="imagens/play.png"></a>
                            <a href="#" onclick="pause2()" id="pause2" style="display:none;"><img src="imagens/pause.png"></a>
                        </div></center>
                </div>
            </div>
            <div id="radios" style="width: 100%;">
                <div id="es" style="float: left; width: 40%;">
                    <center>
                        <br><div>
                            <label id="texto">Aracati - </label>
                            <label id="teste">98.1</label>
                        </div><br> 
                        <audio id="audio3" preload="auto">
                            <source src="http://198.24.156.115:9304/;" type="audio/ogg">
                        </audio>
                        <div>
                            <a href="#" onclick="play3()" id="play3" ><img src="imagens/play.png"></a>
                            <a href="#" onclick="pause3()" id="pause3"style="display:none;"><img src="imagens/pause.png"></a>
                        </div></center>
                </div>
                <div id="di" style="float: right; width: 40%;">
                    <center>
                        <br><div>
                            <label id="texto">Sobral - </label>
                            <label id="teste">106.1</label>
                        </div><br> 
                        <audio id="audio4" preload="auto">
                            <source src="http://198.24.156.115:9306/;" type="audio/ogg">
                        </audio>
                        <div>
                            <a href="#" onclick="play4()" id="play4"><img src="imagens/play.png"></a>
                            <a href="#" onclick="pause4()" id="pause4"style="display:none;"><img src="imagens/pause.png"></a>
                        </div></center>
                </div>
            </div>
            <div id="radios" style="width: 100%;">
                <div id="es" style="float: left; width: 40%;">
                    <center>
                       <br><div>
                            <label id="texto">Crateús - </label>
                            <label id="teste">93.3</label>
                        </div><br> 
                        <audio id="audio5" preload="auto">
                            <source src="http://198.24.156.115:9308/;" type="audio/ogg">
                        </audio>
                        <div>
                            <a href="#" onclick="play5()" id="play5"><img src="imagens/play.png"></a>
                            <a href="#" onclick="pause5()" id="pause5"style="display:none;"><img src="imagens/pause.png"></a>
                        </div></center>
                </div>
                <div id="di" style="float: right; width: 40%;">
                    <center>
                        <br><div>
                            <label id="texto">Redenção -</label>
                            <label id="teste"> 98.7</label>
                        </div><br>
                        <audio id="audio6" preload="auto">
                            <source src="http://198.24.156.115:9310/;" type="audio/ogg">
                        </audio>
                        <div>
                            <a href="#" onclick="play6()" id="play6"><img src="imagens/play.png"></a>
                            <a href="#" onclick="pause6()" id="pause6"style="display:none;"><img src="imagens/pause.png"></a>
                        </div></center>
                </div>
            </div>
            <div id="radios" style="width: 100%;">
                <div id="es" style="float: left; width: 40%;">
                    <center>
                        <br><div>
                            <label id="texto">Santa Quitéria -</label>
                            <label id="teste"> 106.5</label>
                        </div><br>
                        <audio id="audio7" preload="auto">
                            <source src="http://198.24.156.115:9316/;" type="audio/ogg">
                        </audio>
                        <div>
                            <a href="#" onclick="play7()" id="play7"><img src="imagens/play.png"></a>
                            <a href="#" onclick="pause7()" id="pause7"style="display:none;"><img src="imagens/pause.png"></a>                
                        </div></center>
                </div>
                <div id="di" style="float: right; width: 40%;">
                    <center>
                        <br><div>
                            <label id="texto">Iguatu/Carius -</label>
                            <label id="teste"> 91.5</label>
                        </div><br>
                        <audio id="audio8" preload="auto">
                            <source src="http://198.24.156.115:9300/;" type="audio/ogg">
                        </audio>
                        <div>
                            <a href="#" onclick="play8()" id="play8"><img src="imagens/play.png"></a>
                            <a href="#" onclick="pause8()" id="pause8"style="display:none;"><img src="imagens/pause.png"></a>
                        </div></center>
                </div>
            </div>
        </div>
        <script>
            audio = document.getElementById('audio');
            audio2 = document.getElementById('audio2');
            audio3 = document.getElementById('audio3');
            audio3 = document.getElementById('audio4');
            audio5 = document.getElementById('audio5');
            audio8 = document.getElementById('audio6');
            audio7 = document.getElementById('audio7');
            audio8 = document.getElementById('audio8');
            function play() {
                audio2.pause();
                audio3.pause();
                audio4.pause();
                audio5.pause();
                audio6.pause();
                audio7.pause();
                audio8.pause();
                audio.play();
                document.getElementById('play').style.display = 'none';
                document.getElementById('play2').style.display = 'block';
                document.getElementById('play3').style.display = 'block';
                document.getElementById('play4').style.display = 'block';
                document.getElementById('play5').style.display = 'block';
                document.getElementById('play6').style.display = 'block';
                document.getElementById('play7').style.display = 'block';
                document.getElementById('play8').style.display = 'block';
                document.getElementById('pause2').style.display = 'none';
                document.getElementById('pause3').style.display = 'none';
                document.getElementById('pause4').style.display = 'none';
                document.getElementById('pause5').style.display = 'none';
                document.getElementById('pause6').style.display = 'none';
                document.getElementById('pause7').style.display = 'none';
                document.getElementById('pause8').style.display = 'none';
                document.getElementById('pause').style.display = 'block';
            }
            function pause() {
                document.getElementById('play').style.display = 'block';
                document.getElementById('pause').style.display = 'none';
                audio.pause();
            }
            function play2() {
                audio.pause();
                audio3.pause();
                audio4.pause();
                audio5.pause();
                audio6.pause();
                audio7.pause();
                audio7.pause();
                audio2.play();
                document.getElementById('play2').style.display = 'none';
                document.getElementById('pause2').style.display = 'block';
                document.getElementById('pause').style.display = 'none';
                document.getElementById('play').style.display = 'block';
                document.getElementById('pause3').style.display = 'none';
                document.getElementById('play3').style.display = 'block';
                document.getElementById('pause4').style.display = 'none';
                document.getElementById('play4').style.display = 'block';
                document.getElementById('pause5').style.display = 'none';
                document.getElementById('play5').style.display = 'block';
                document.getElementById('pause6').style.display = 'none';
                document.getElementById('play6').style.display = 'block';
                document.getElementById('pause7').style.display = 'none';
                document.getElementById('play7').style.display = 'block';
                document.getElementById('pause8').style.display = 'none';
                document.getElementById('play8').style.display = 'block';
            }
            function pause2() {
                document.getElementById('play2').style.display = 'block';
                document.getElementById('pause2').style.display = 'none';
                audio2.pause();
            }
            function play3() {
                audio.pause();
                audio2.pause();
                audio4.pause();
                audio5.pause();
                audio6.pause();
                audio7.pause();
                audio7.pause();
                audio3.play();
                document.getElementById('play3').style.display = 'none';
                document.getElementById('pause3').style.display = 'block';
                document.getElementById('pause').style.display = 'none';
                document.getElementById('play').style.display = 'block';
                document.getElementById('pause2').style.display = 'none';
                document.getElementById('play2').style.display = 'block';
                document.getElementById('pause4').style.display = 'none';
                document.getElementById('play4').style.display = 'block';
                document.getElementById('pause5').style.display = 'none';
                document.getElementById('play5').style.display = 'block';
                document.getElementById('pause6').style.display = 'none';
                document.getElementById('play6').style.display = 'block';
                document.getElementById('pause7').style.display = 'none';
                document.getElementById('play7').style.display = 'block';
                document.getElementById('pause8').style.display = 'none';
                document.getElementById('play8').style.display = 'block';
            }
            function pause3() {
                audio3.pause();
                document.getElementById('play3').style.display = 'block';
                document.getElementById('pause3').style.display = 'none';
            }
            function play4() {
                audio.pause();
                audio2.pause();
                audio3.pause();
                audio5.pause();
                audio6.pause();
                audio7.pause();
                audio7.pause();
                audio4.play();
                document.getElementById('play4').style.display = 'none';
                document.getElementById('pause4').style.display = 'block';
                document.getElementById('pause').style.display = 'none';
                document.getElementById('play').style.display = 'block';
                document.getElementById('pause2').style.display = 'none';
                document.getElementById('play2').style.display = 'block';
                document.getElementById('pause3').style.display = 'none';
                document.getElementById('play3').style.display = 'block';
                document.getElementById('pause5').style.display = 'none';
                document.getElementById('play5').style.display = 'block';
                document.getElementById('pause6').style.display = 'none';
                document.getElementById('play6').style.display = 'block';
                document.getElementById('pause7').style.display = 'none';
                document.getElementById('play7').style.display = 'block';
                document.getElementById('pause8').style.display = 'none';
                document.getElementById('play8').style.display = 'block';

            }
            function pause4() {
                audio4.pause();
                document.getElementById('play4').style.display = 'block';
                document.getElementById('pause4').style.display = 'none';
            }
            function play5() {
                audio.pause();
                audio2.pause();
                audio3.pause();
                audio4.pause();
                audio6.pause();
                audio7.pause();
                audio7.pause();
                audio5.play();
                document.getElementById('play5').style.display = 'none';
                document.getElementById('pause5').style.display = 'block';
                document.getElementById('pause').style.display = 'none';
                document.getElementById('play').style.display = 'block';
                document.getElementById('pause2').style.display = 'none';
                document.getElementById('play2').style.display = 'block';
                document.getElementById('pause3').style.display = 'none';
                document.getElementById('play3').style.display = 'block';
                document.getElementById('pause4').style.display = 'none';
                document.getElementById('play4').style.display = 'block';
                document.getElementById('pause6').style.display = 'none';
                document.getElementById('play6').style.display = 'block';
                document.getElementById('pause7').style.display = 'none';
                document.getElementById('play7').style.display = 'block';
                document.getElementById('pause8').style.display = 'none';
                document.getElementById('play8').style.display = 'block';
            }
            function pause5() {
                audio5.pause();
                document.getElementById('play5').style.display = 'block';
                document.getElementById('pause5').style.display = 'none';
            }
            function play6() {
                audio.pause();
                audio2.pause();
                audio3.pause();
                audio4.pause();
                audio5.pause();
                audio7.pause();
                audio7.pause();
                audio6.play();
                document.getElementById('play6').style.display = 'none';
                document.getElementById('pause6').style.display = 'block';
                document.getElementById('pause').style.display = 'none';
                document.getElementById('play').style.display = 'block';
                document.getElementById('pause2').style.display = 'none';
                document.getElementById('play2').style.display = 'block';
                document.getElementById('pause3').style.display = 'none';
                document.getElementById('play3').style.display = 'block';
                document.getElementById('pause4').style.display = 'none';
                document.getElementById('play4').style.display = 'block';
                document.getElementById('pause5').style.display = 'none';
                document.getElementById('play5').style.display = 'block';
                document.getElementById('pause7').style.display = 'none';
                document.getElementById('play7').style.display = 'block';
                document.getElementById('pause8').style.display = 'none';
                document.getElementById('play8').style.display = 'block';
            }
            function pause6() {
                audio6.pause();
                document.getElementById('play6').style.display = 'block';
                document.getElementById('pause6').style.display = 'none';
            }
            function play7() {
                audio.pause();
                audio2.pause();
                audio3.pause();
                audio4.pause();
                audio5.pause();
                audio6.pause();
                audio8.pause();
                audio7.play();
                document.getElementById('play7').style.display = 'none';
                document.getElementById('pause7').style.display = 'block';
                document.getElementById('pause').style.display = 'none';
                document.getElementById('play').style.display = 'block';
                document.getElementById('pause2').style.display = 'none';
                document.getElementById('play2').style.display = 'block';
                document.getElementById('pause3').style.display = 'none';
                document.getElementById('play3').style.display = 'block';
                document.getElementById('pause4').style.display = 'none';
                document.getElementById('play4').style.display = 'block';
                document.getElementById('pause5').style.display = 'none';
                document.getElementById('play5').style.display = 'block';
                document.getElementById('pause6').style.display = 'none';
                document.getElementById('play6').style.display = 'block';
                document.getElementById('pause8').style.display = 'none';
                document.getElementById('play8').style.display = 'block';
            }
            function pause7() {
                audio7.pause();
                document.getElementById('play7').style.display = 'block';
                document.getElementById('pause7').style.display = 'none';
            }
            function play8() {
                audio.pause();
                audio2.pause();
                audio3.pause();
                audio4.pause();
                audio5.pause();
                audio6.pause();
                audio7.pause();
                audio8.play();
                document.getElementById('play8').style.display = 'none';
                document.getElementById('pause8').style.display = 'block';
                document.getElementById('pause').style.display = 'none';
                document.getElementById('play').style.display = 'block';
                document.getElementById('pause2').style.display = 'none';
                document.getElementById('play2').style.display = 'block';
                document.getElementById('pause3').style.display = 'none';
                document.getElementById('play3').style.display = 'block';
                document.getElementById('pause4').style.display = 'none';
                document.getElementById('play4').style.display = 'block';
                document.getElementById('pause5').style.display = 'none';
                document.getElementById('play5').style.display = 'block';
                document.getElementById('pause6').style.display = 'none';
                document.getElementById('play6').style.display = 'block';
                document.getElementById('pause7').style.display = 'none';
                document.getElementById('play7').style.display = 'block';
            }
            function pause8() {
                audio8.pause();
                document.getElementById('play8').style.display = 'block';
                document.getElementById('pause8').style.display = 'none';
            }
        </script>
    </body>
</html>
