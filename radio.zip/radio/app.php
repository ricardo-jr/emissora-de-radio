<!DOCTYPE html> 
<html> 
<body preload = "enableAutoplay()"> 

<button onclick="enableAutoplay()" type="button">Enable autoplay</button>
<button onclick="disableAutoplay()" type="button">Disable autoplay</button>
<button onclick="checkAutoplay()" type="button">Check autoplay status</button><br> 


<div class="hidden">
	<script type="text/javascript">
		<!--//--><![CDATA[//><!--
			var images = new Array()
			function preload() {
				for (i = 0; i < preload.arguments.length; i++) {
					images[i] = new Image()
					images[i].src = preload.arguments[i]
				}
			}
			preload(
				"http://domain.tld/gallery/image-001.jpg",
				"http://domain.tld/gallery/image-002.jpg",
				"http://domain.tld/gallery/image-003.jpg"
			)
		//--><!]]>
	</script>
</div>

<script>
var vid = document.getElementById("audiomusic");
function enableAutoplay() { 
    vid.autoplay = true;
    vid.load();
}

function disableAutoplay() { 
    vid.autoplay = false;
    vid.load();
} 

function checkAutoplay() { 
    alert(vid.autoplay);
} 
</script> 

<p>Video courtesy of <a href="https://www.bigbuckbunny.org/" target="_blank">Big Buck Bunny</a>.</p>

</body> 
</html>
