<!DOCTYPE html>
<?php
$radios = ['rede', 'Paraipaba', 'Aracati', 'Sobral', 'Crateús', 'Redenção', 'Santa Quitéria', 'Iguatu/Carius'];
$frequencias = ['', '-88.7', '-98.1', '-105.1', '-93.3', '-98.7', '-106.5', '-91.5'];
$streaming = ['http://198.24.156.115:9300/;', 'http://198.24.156.115:9302/;', 'http://198.24.156.115:9304/;', 'http://198.24.156.115:9306/;', 'http://198.24.156.115:9308/;', 'http://198.24.156.115:9310/;', 'http://198.24.156.115:9316/;', 'http://198.24.156.115:9300/;'];
//se liga, a transmissão da primeira rádio e da ultima são iguais, smp
//slg?
?>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title></title>
        <script src="jquery.min.js"></script>
    </head>
    <style>
        @font-face {
            font-family: "Testando";
            src: url("fonts/coco.ttf"); /* para IE */
        }
        #texto{ 
            font-family: "Testando"; 
        }
        @font-face {
            font-family: "numero";
            src: url("fonts/nexa.otf"); /* para IE */
        }
        #teste{ 
            font-family: "numero"; 
        }
        #radios img{
            width: 70px;
            height: 70px;
        }
        body{
            background-image: url("imagens/BG.jpg"); 
            color: #f0fd5f;
            font-size: 15px;
        }
    </style>
    <body>
        <div id="container" >
            <div id="logo" >
                <center><img src="imagens/logo.png"></center>
            </div>     
            <div id="radios" style="width: 100%;">
                <?php
                for ($x = 0; $x < count($radios); $x++) {
                    if ($x % 2 == 0) {
                        ?>    

                        <div id="es" style="float: left; width: 40%;">
                            <center>

                                <audio tabindex="0" id="audio<?php echo $x; ?>"  preload="auto" type="audio/mp3">
                                    <source src="<?php echo $streaming[$x]; ?>" type="audio/ogg">
                                </audio>
                                <div>
                                    <a href="#" class="testeClick"  id="play<?php echo $x; ?>"><img src="imagens/play.png"></a>
                                    <a href="#" class="testeClickPause" style="display:none;" id="pause<?php echo $x; ?>"><img src="imagens/pause.png"></a>     
                                </div>
                                <br>
                                <div>
                                    <label id="texto"><?php echo $radios[$x]; ?></label>
                                    <label id="teste"><?php echo $frequencias[$x]; ?></label>
                                </div><br> 
                            </center>
                        </div>
                        <?php
                    } else {
                        ?>
                        <div id="di" style="float: right; width: 40%;">
                            <center>

                                <audio tabindex="0" id="audio<?php echo $x; ?>"  preload="auto" type="audio/mp3">
                                    <source src="<?php echo $streaming[$x]; ?>" type="audio/ogg">
                                </audio>
                                <div>
                                    <a href="#" class="testeClick" id="play<?php echo $x; ?>"><img src="imagens/play.png"></a>
                                    <a href="#" class="testeClickPause" style="display:none;" id="pause<?php echo $x; ?>"><img src="imagens/pause.png"></a>     
                                </div>
                                <br>
                                <div>
                                    <label id="texto"><?php echo $radios[$x]; ?></label>
                                    <label id="teste"><?php echo $frequencias[$x]; ?></label>
                                </div><br> 
                            </center>
                        </div>
                        <?php
                    }
                    ?>
                    
                <?php }
                ?>
            </div>
        </div>
        <script>
            $(document).ready(function () {
                $(".testeClick").click(function () {
                    var idClicado = $(this).attr("id");
                    var valorNumericoId = idClicado.substr(4, 1);
                    for (var i = 0; i < 8; i++) {
                        var audioIdIncrement = document.getElementById('audio' + i);
                        if (i == valorNumericoId) {
                            $(this).css("display", "none");
                            $(".testeClickPause#pause" + valorNumericoId).css("display", "block");
                            audioIdIncrement.play();
                        } else if (i != valorNumericoId) {
                            $(".testeClick#play" + i).css("display", "block");
                            $(".testeClickPause#pause" + i).css("display", "none");
                            audioIdIncrement.pause();
                            audioIdIncrement.currentTime = 0;
                        }
                    }
                });
                $(".testeClickPause").click(function () {
                    var idClicado = $(this).attr("id");
                    var valorNumericoId = idClicado.substr(5, 1);
                    var audioIdIncrement = document.getElementById('audio' + valorNumericoId);
                    $(".testeClick#play" + valorNumericoId).css("display", "block");
                    $(".testeClickPause#pause" + valorNumericoId).css("display", "none");
                    audioIdIncrement.pause();
                    audioIdIncrement.currentTime = 0;
                });
            });
        </script>
    </body>
</html>