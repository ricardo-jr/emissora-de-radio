<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="#" method="post">
            <input type="checkbox" name="caixas[]" value ="Corte">
            <input type="checkbox" name="caixas[]" value ="Barba">
            <input type="checkbox" name="caixas[]" value ="Teste">
            <input type="checkbox" name="caixas[]" value ="Teste">
            <input type="submit" value="enviar">
        </form>
        <?php
        $con = mysqli_connect("localhost", "root", "", "id4073132_barbearia");
        $nome = "ricardo";
        if (isset($_POST['caixas'])) {
            $_checkbox = $_POST['caixas'];
            foreach ($_checkbox as $valor) {
                $sql = "insert into servico_barbeiro(barbeiro, servico) values('".$nome."', '".$valor."')";
                mysqli_query($con, $sql);
            }
        }
        ?>
    </body>
</html>
